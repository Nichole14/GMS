<?php

    $a = "yeah";